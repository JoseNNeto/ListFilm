package com.example.superfilmes;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.superfilmes.modelo.Usuario;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class CadastroActivity extends AppCompatActivity {

    private EditText etNome;
    private EditText etEmail;
    private EditText etSenha;
    public Button btCadastrar;
    private FirebaseAuth mAuth;
    private Usuario u;
    String UsuarioID;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        etNome = findViewById(R.id.etNome);
        etEmail = findViewById(R.id.etEmail);
        etSenha = findViewById(R.id.etSenha);
        btCadastrar = findViewById(R.id.btCadastrar);
        mAuth = FirebaseAuth.getInstance();


        btCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                recuperarDados();
                criarLogin();
                salvarDadosUsuario();
                telaPrincipal();
            }
        });
    }


    private void salvarDadosUsuario() {
        String nome = etNome.getText().toString();

        FirebaseFirestore db = FirebaseFirestore.getInstance();

        Map<String,Object> usuarios = new HashMap<>();
        usuarios.put("nome", nome);

        UsuarioID = FirebaseAuth.getInstance().getCurrentUser().getUid();

        DocumentReference documentoReferencia = db.collection("Usuarios").document(UsuarioID);
        documentoReferencia.set(usuarios).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Log.d("db", "Sucesso ao salvar os dados");
            }
        })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.d("db_errror", "Erro ao salvar so dados" + e.toString());
                    }
                });
    }

    private void criarLogin() {
        mAuth.createUserWithEmailAndPassword(u.getEmail(), u.getSenha())
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()) {
                            FirebaseUser user = mAuth.getCurrentUser();
                            u.setId(user.getUid());
                            u.salvarDados();
                            startActivity(new Intent(CadastroActivity.this, MainActivity.class));
                        } else {
                            Toast.makeText(CadastroActivity.this, "Erro ao criar uma conta", Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }

    private void recuperarDados() {
        if(etNome.getText().toString().equals("") || etEmail.getText().toString().equals("") || etSenha.getText().toString().equals("")){
            Toast.makeText(this,"Você deve preencher todos os campos",Toast.LENGTH_LONG).show();
        } else {
            u = new Usuario();
            u.setNome((etNome.getText().toString()));
            u.setEmail(etEmail.getText().toString());
            u.setSenha(etSenha.getText().toString());
        }
    }
    private void telaPrincipal() {
        startActivity(new Intent(this, MainActivity.class));
    }
}