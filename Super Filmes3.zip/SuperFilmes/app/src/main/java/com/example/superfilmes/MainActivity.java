package com.example.superfilmes;

import static androidx.navigation.Navigation.findNavController;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {


    private View bottomNavigationView;
    private NavController navController;
    private Object appBarConfiguration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment selectedFragment = null;

                switch (item.getItemId()){
                    case R.id.popularFragment:
                        selectedFragment = new PopularFragment();
                        break;
                    case R.id.favoritoFragment:
                        selectedFragment = new FavoritoFragment();
                        break;
                    case R.id.perfilFragment:
                        selectedFragment = new LogoutFragment();
                        FirebaseAuth.getInstance().signOut();
                        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                        startActivity(intent);
                        finish();
                        break;
            }
                getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView, selectedFragment).commit();
                return true;
            }
        });
    }
}
//NavController navController;
//navController = findNavController(this, R.id.nav_host_fragment_container);
//appBarConfiguration = AppBarConfiguration(setOf(this, R.id.popularFragment, R.id.favoritoFragment, R.id.perfilFragment));

//setupWithNavController(bottomNavigationView, navController);