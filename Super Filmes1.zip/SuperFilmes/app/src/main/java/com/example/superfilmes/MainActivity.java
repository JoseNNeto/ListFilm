package com.example.superfilmes;

import static androidx.navigation.Navigation.findNavController;

import static com.google.firebase.components.Dependency.setOf;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.ui.AppBarConfiguration;

import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {


    private View bottomNavigationView;
    private NavController navController;
    private Object appBarConfiguration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        navController = findNavController(R.id.bottomNavigationView);
        appBarConfiguration = AppBarConfiguration(setOf(R.id.popularFragment, R.id.favoritoFragment, R.id.perfilFragment));
        
        bottomNavigationView.setupWithNavController(navController);
    }

    private NavController findNavController(int bottomNavigationView) {
    }
}